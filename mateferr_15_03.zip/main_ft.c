/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_ft.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mateferr <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/09 09:58:25 by mateferr          #+#    #+#             */
/*   Updated: 2025/03/09 21:35:02 by mateferr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "rush01.h"

int	main(int argc, char *argv[])
{
	char			*views;
	unsigned int	matrix[PZL_SZ][PZL_SZ];
	unsigned int	pzl_map[PZL_SZ][PZL_SZ];

	PZL_SZ = 4;
	if (error(argv[1]))
		return (0);
	views = ft_str(argv[1]);
	ft_rows_columns(matrix, views);
	create_matrix(pzl_map);
	set_seq_val(matrix, pzl_map);
	set_value_n(matrix, pzl_map);
	findAllSolutions(pzl_map, 0, 0, matrix);
}
