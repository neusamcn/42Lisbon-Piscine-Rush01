/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   begin.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mateferr <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/08 17:30:26 by mateferr          #+#    #+#             */
/*   Updated: 2025/03/09 16:43:16 by mateferr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush01.h"

char	*ft_str(char *str)
{
	int		i;
	int		j;
	char	*str2;

	str2 = malloc(16);
	i = 0;
	j = 0;
	while (j < 16)
	{
		if (str[i] != ' ')
		{
			str2[j] = str[i];
			j++;
		}
		i++;
	}
	str2[j] = '\0';
	return (str2);
}

void	ft_rows_columns(unsigned int rc[PZL_SZ][PZL_SZ], char *str)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	k = 0;
	while (i < PZL_SZ)
	{
		j = 0;
		while (j < PZL_SZ)
		{
			rc[i][j] = str[k] - '0';
			j++;
			k++;
		}
		i++;
	}
	free(str);
}

void	create_matrix(unsigned int rc[PZL_SZ][PZL_SZ])
{
	int	i;
	int	j;

	i = 0;
	while (i < PZL_SZ)
	{
		j = 0;
		while (j < PZL_SZ)
		{
			rc[i][j] = 0;
			j++;
		}
		i++;
	}
}
