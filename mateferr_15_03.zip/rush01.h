/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mateferr <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/15 13:45:26 by mateferr          #+#    #+#             */
/*   Updated: 2025/03/15 13:45:36 by mateferr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH01_H
# define RUSH01_H

extern int PZL_SZ;

char	*ft_str(char *str);
void	ft_rows_columns(unsigned int rc[PZL_SZ][PZL_SZ], char *str);
void	create_matrix(unsigned int rc[PZL_SZ][PZL_SZ]);
void	set_value_n(unsigned int input_grid[PZL_SZ][PZL_SZ], 
	unsigned int pzl_map[PZL_SZ][PZL_SZ]);
void	set_seq_val(unsigned int input_grid[PZL_SZ][PZL_SZ], 
	unsigned int pzl_map[PZL_SZ][PZL_SZ]);
int		unique(unsigned int matrix[PZL_SZ][PZL_SZ], 
	unsigned int row, unsigned int col, unsigned num);
void	print_matrix(unsigned int matrix[PZL_SZ][PZL_SZ]);
void	find_all_solutions(unsigned int matrix[PZL_SZ][PZL_SZ], 
	unsigned int row, unsigned int col, unsigned int views[PZL_SZ][PZL_SZ]);
int		validate_grid(unsigned int matrix[PZL_SZ][PZL_SZ], 
	unsigned int views[PZL_SZ][PZL_SZ]);
int		error(char *input_string);

# endif
