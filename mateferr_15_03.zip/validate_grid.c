/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_grid.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mateferr <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/09 20:09:51 by mateferr          #+#    #+#             */
/*   Updated: 2025/03/15 14:19:50 by mateferr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	views_up_down(unsigned int matrix[PZL_SZ][PZL_SZ], unsigned int views[PZL_SZ][PZL_SZ])
{
	int	c;
	int	l;
	int	count;
	
	c = 0;
	while (c < PZL_SZ)
	{
		l = 0;
		count = 1;
		while (l < (PZL_SZ - 1) && matrix[l][c] != PZL_SZ)
		{
			if (matrix[l][c] < matrix[l + 1][c])
				count++;
			l++;
		}
		if (count != views[0][c])
		{
			return (0);
		}
		c++;
	}
	return (1);
}
int	views_down_up(unsigned int matrix[PZL_SZ][PZL_SZ], unsigned int views[PZL_SZ][PZL_SZ])
{
	int	c;
	int	l;
	int	count;
	
	c = 0;
	while (c < PZL_SZ)
	{
		count = 1;
		l = PZL_SZ - 1;
		while (l >= 0 && matrix[l][c] != PZL_SZ)
		{
			if (matrix[l][c] < matrix[l - 1][c])
				count++;
			l--;
		}
		if (count != views[1][c])
		{
			return (0);
		}
		c++;
	}
	return (1);
}
int     views_left_right(unsigned int matrix[PZL_SZ][PZL_SZ], unsigned int views[PZL_SZ][PZL_SZ])
{
	int	c;
	int	l;
	int	count;
	
	l = 0;
	while (l < PZL_SZ)
	{
		c = 0;
		count = 1;
		while (c < (PZL_SZ - 1) && matrix[l][c] != PZL_SZ)
		{
			if (matrix[l][c] < matrix[l][c + 1])
				count++;
			c++;
		}
		if (count != views[2][l])
		{
			return (0);
		}
		l++;
	}
	return (1);
}
int     views_right_left(unsigned int matrix[PZL_SZ][PZL_SZ], unsigned int views[PZL_SZ][PZL_SZ])
{
	int	c;
	int	l;
	int	count;
	
	l = 0;
	while (l < PZL_SZ)
	{
		c = PZL_SZ - 1;
		count = 1;
		while (c >= 0 && matrix[l][c] != PZL_SZ)
		{
			if (matrix[l][c] < matrix[l][c - 1])
				count++;
			c--;
		}
		if (count != views[3][l])
		{
			return (0);
		}
		l++;
	}
	return (1);
}
int	validate_grid(unsigned int matrix[PZL_SZ][PZL_SZ], unsigned int views[PZL_SZ][PZL_SZ])
{
	if (views_up_down(matrix, views))
	{
		if (views_left_right(matrix, views))
		{
			if (views_left_right(matrix, views))
			{
				if (views_left_right(matrix, views))
				{
					return (1);
				}
			}
		}
	}
	return (0);
}
